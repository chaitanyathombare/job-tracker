import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('jobs')

def handler(event, context):

    print(event)
    body = {}
    statusCode = 200
    headers = {
        "Content-Type": "application/json"
    }

    user_id = "demo-user"

    # response = table.get_item(
    #             Key={'job_id': event['pathParameters']['job_id']})
    
    # body = body["Item"]
    # responseBody = [{'price': float(body['price']), 'id': body['id'], 'name': body['name']}]
    # body = responseBody
    
    

    # response = table.query(
    #     KeyConditionExpression="user_id = :uid",
    #     ExpressionAttributeValues={":uid": user_id}
    # )

    return {
        "statusCode": 200
        # "body": json.dumps(response['Items'])
    }